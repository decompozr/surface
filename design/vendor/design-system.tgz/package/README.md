# DecompozR design system

Private, domain-agnostic Svelte 5 components for quiet, dense software interfaces. Milk Green paired light/dark semantics with a white light canvas, green charcoal dark surfaces and soft green selection states, matte treatments, Inter and the original DecompozR identity. This repository owns the library, catalog and Storybook; application meaning stays in the consumer.

The package is `@decompozr/design-system`, private and unreleased at `0.0.0`. Distribution is an exact local `.tgz`, not an npm registry release. `package.json` is the version authority; identify candidates by SHA-256 as well as version.

## Build and install locally

```sh
npm ci
npm run check
npm pack
shasum -a 256 release/decompozr-design-system-0.0.0.tgz
```

`npm pack` rebuilds `dist/` and TypeScript declarations, then writes the archive to `release/` through the repository `.npmrc`. Generated `.tgz` files remain ignored by Git. Install the resulting file in a Svelte 5 consumer using its package manager:

```sh
npm install /absolute/path/to/design-system/release/decompozr-design-system-0.0.0.tgz
```

Use a hash-named copy for successive candidates to avoid ambiguous 0.0.0 caching. Retain the file, hash and consumer lockfile. Rebuild and reinstall after source changes; existing consumers are not automatically updated. See [local consumer and Surface installation](docs/local-consumer-installation.md) for host-specific steps.

```svelte
<script lang="ts">
  import '@decompozr/design-system/fonts.css';
  import { TextField, Select, Button, spacing } from '@decompozr/design-system';
  let name = $state('notes.md');
  let format = $state('plain');
</script>

<form style:display="grid" style:gap={spacing[4]}
  onsubmit={(event) => event.preventDefault()}>
  <TextField label="File name" name="name" bind:value={name} size="compact" required />
  <Select label="Format" name="format" bind:value={format} size="compact"
    options={[{ value: 'plain', label: 'Plain text' }]} />
  <Button type="submit" size="compact">Apply</Button>
</form>
```

Import `fonts.css` once. Components do not require catalog CSS, SvelteKit aliases or global resets. Edit `src/lib`, never generated `dist` or installed copies. The font stylesheet adds the bundled font face without styling global elements.

## Visual grammar

| Foundation | Current contract |
| --- | --- |
| Color | Milk Green paired light/dark roles feed `semanticColors`; use surface/text/border/interactive/selected/focus/status roles in components |
| Type | body 14/20, bodyCompact 13/18, label 14/20 medium, labelCompact 13/18 medium, caption 12/16, heading 16/24 semibold, code 14/20, codeCompact 13/18 |
| Density | normal 2.25rem minimum, compact 1.75rem minimum; coarse-pointer targets at least 2.75rem |
| Rhythm | 2px micro-step, 4px label/support, 8px related controls, 16px groups; larger steps remain available |
| Borders | 1px; quiet separators and stronger control boundaries have distinct semantic roles |
| Radius | control 4px, surface 6px; full radius reserved for circles/switch geometry |
| Focus | shared 2px Milk Green outline, 2px theme-surface separation; preserve forced-color visibility |
| Elevation | one restrained floating shadow; ordinary content needs none |

Pixel equivalents assume a 16px root. Geometry/type use rem and unitless leading, so user text preferences remain effective. Do not force the root font size or shrink interaction targets to achieve density. `typographyStyle(role)` applies a role to consumer-owned semantic HTML. Prefer spacing, typography and separators over extra cards.

`Text` accepts `variant`, semantic `as`, string `text` or a children snippet, `tone` and native attributes. Legacy size aliases remain: body→body, small→bodyCompact, heading/title→heading, eyebrow→caption; variant takes precedence. Code roles use the platform monospace stack.

### Identity and icons

`Logo` supports full/compact, current transparent `milk-green`, approved transparent `white`, and four transparent legacy foreground palettes (cream, charcoal, sage, slate), accessible `label`, numeric-pixel or CSS-length `size`, and an optional compact `centerSymbol`. Compact retains the filled curly-loop paths and opposing arrows; its symbol occupies about 81% of viewbox width. For interface identity, prefer 44px and inspect the 32/38/44/64px specimens for constrained contexts. The standalone brand guide recommends starting at 32px for the icon and 160px for the full lockup; these are contextual recommendations, not universal minimums. Explicit sizes are bounded by available width. The bracket joins are gently refined; the adopted center uses two rounded upper segments with 1:2 lengths and a 6-unit gap above one continuous lower block, each 47 units thick, across a 120×100 stack with matched 6-unit horizontal and vertical gaps; wordmark metrics and proportions remain unchanged; the tagline is not part of Logo.

`Logo optical="auto"` selects two horizontal rounded center blocks for compact marks with explicit numeric size≤32px. CSS-length and implicit sizes use the standard construction unless `optical="small"` is specified; `optical="standard"` forces the thicker main center. Full lockups remain standard, and compact `centerSymbol` takes precedence. Standalone optical icons are exported as `icon-small-milk-green-light.svg`, `icon-small-milk-green-dark.svg` and `icon-small-white.svg`; resizing a standard SVG does not switch its construction.

The current Milk Green logo uses four independent brand roles for the frame/wordmark, upper pieces, lower block and terminal R. Legacy palettes retain their exact reference foreground pigments with only the backplate removed. Brand color and semantic feedback meaning remain separate. [Selected reference](docs/design-system-assets/selected-logo-reference.jpg) and [curly-loop reference](docs/design-system-assets/curly-loop-logo-reference.png) remain the visual sources; the refined vector and wordmark font are engineering estimates, not original supplied vector/font assets.

`Icon` wraps the pinned Lucide subset: `name`, optional accessible `label`, and `size` (default 1.25rem). Numeric sizes mean CSS pixels; rem/em strings scale. Decorative icons omit label. Icon size is independent of hit-target size. Keep [Lucide provenance](src/lib/lucide-provenance.json), [ISC license](src/lib/lucide-LICENSE) and [Inter OFL](src/lib/fonts/inter-OFL.txt) with the assets.

## Shipped components

| Family | Components |
| --- | --- |
| Identity/type | Logo, Icon, Text |
| Actions | Button, IconButton, ToggleButton, Spinner |
| Forms | TextField, TextArea, FieldLabel, Select, Slider, Checkbox, Switch, RadioGroup |
| Document editing | MarkdownEditor |
| Composite controls | Toolbar, ToggleGroup |
| Overlays | Tooltip, Menu |
| Supporting content | Badge, Tag, Toast, ToastRegion, StatusIndicator |
| Hierarchical data | Tree |
| Theme boundary | Theme |
| Generic separator | Divider |
| Existing optional compositions | AppHeader, Brand, NavigationLinks, Breadcrumbs, AppShell, SidePanel, SurfaceCard, FloatingComposer, StatusBar, SelectionOutline, SurfaceTabs, DragHandle |

The 40 exported components are not a complete IDE widget inventory. SurfaceTabs provides controlled open-content tabs; Tree provides single-selection hierarchy; MarkdownEditor provides lossless block editing and reorder; data-grid behaviors and public Dialog/Popover primitives are not implemented. Existing optional compositions remain compatible with their [separate contract](docs/surface-consumer-api.md); their layout is not a required application architecture. The catalog drawer and verification dialog are examples, not public components.

`Tree` accepts stable `TreeItem` data, an accessible `label`, bindable `selectedId` and `expandedIds`; consumers own the hierarchy and persistence. See the [keyboard, expansion and update contract](docs/design-system-tree.md).

`MarkdownEditor` accepts an accessible `label` and bindable Markdown `value`, with `onchange`, `readOnly`, `disabled` and `size`. It edits and moves individual blocks while preserving untouched source; saving belongs to the consumer. See the [block editing and lossless-source contract](docs/design-system-markdown-editor.md).

AppShell supports opt-in mobile edge gestures with `edgeSwipes={true}` alongside all navigation modes, including width-preserving `push`. Existing buttons and bound state remain authoritative. See the [gesture API, exclusions and Safari limits](docs/edge-swipes.md).

For actual 32px coarse-pointer rows, add `touchDensity="compact"`; see [touch row density and its target-size tradeoff](docs/touch-navigation-density.md). Defaults remain unchanged.

Use `NavigationLinks density="compact" touchAppearance="compact"` for quiet mobile link faces inside 44px targets, and `FloatingComposer density="compact"` for tighter section spacing. AppShell pointer opening focuses its named pane; keyboard opening and subsequent Tab retain visible focus. See [compact mobile adoption and verification](docs/compact-mobile.md).

### Actions and selection

Button defaults to `type="button"`; use submit explicitly. Button, IconButton and ToggleButton share normal/compact sizes. Loading keeps content/geometry stable, exposes busy/disabled semantics, suppresses activation and may retain focus. Reduced motion keeps the spinner recognizable without animation. Icon-only actions require names; tooltips are supplemental descriptions.

Checkbox, Switch and RadioGroup retain native form semantics. Checkbox supports mixed state; Switch represents a setting and ToggleButton a pressed action. Density does not change these meanings. Numeric/null legacy input sizes on Checkbox/Switch/Slider remain accepted as normal density.

ToggleGroup supports single/multiple selection, optional empty selection, disabled choices and normal/compact sizing. Arrows move focus; Enter/Space selects. Toolbar supplies one roving tab stop across its actions and nested groups; it owns navigation rather than creating nested keyboard traps. Overflow may scroll rather than making targets unreadably small.

### Text and native controls

TextField, TextArea, FieldLabel, Select, Slider, Checkbox, Switch and RadioGroup support normal/compact density. Labels, values and adjacent actions align. Coarse-pointer editable fields/selects use at least 1rem text.

TextField supports text/email/search, leading icons, trailing actions, `bind:value`, `bind:element` and hidden labels. TextArea keeps native rows plus optional maxHeight/resize. Both forward native attributes/events (autocomplete, inputmode, pattern, maxlength, form, class/style, data/ARIA attributes and callbacks). Use `pattern={'[a-z]{3,8}'}` in Svelte to preserve literal quantifier braces. Class/style target the native element.

`readOnly` and native `readonly` are accepted, with readOnly taking precedence. Readonly values remain focusable/selectable and form-submittable; disabled values are omitted. Native disabled fieldsets also determine disabled appearance. Caller aria-describedby is combined with hint/error descriptions; an error adds explicit text, a critical border and aria-invalid=true, otherwise caller aria-invalid is preserved.

Select retains its native popup, option disabling, bind:element, optional selected-label help and error state. Slider retains native range artwork, min/max/step, value binding, suffix and optional output. Neither has native readonly semantics. Browser-native control rendering may differ across platforms.

### Overlays and feedback

Menu uses ordered `MenuItem` actions with stable IDs, disabled state and optional separators. `compact` controls both trigger and items. Arrow/Home/End navigation, typeahead, Escape return and native Tab/Shift-Tab continuation remain separate from selection. Outside interaction preserves the destination's focus. If live data removes/disables the focused item, focus moves to a remaining action or the menu surface; empty menus still support Escape and Tab.

Menu and Tooltip use a shared private manual-popover lifecycle to escape transformed/clipped ancestors while remaining in their original DOM ancestry, including native dialogs. Placement tracks only while open and respects viewport bounds. The legacy same-node body fallback covers ordinary document contexts, not arbitrary native-modal stacking. Static specimens stay inline. Tooltip supports focus/hover, pointer travel into its surface and Escape dismissal; essential instructions stay visible.

Badge is a passive caption/count, with a 20px minimum at 16px root and optional full accessible label. Tag uses bodyCompact, wraps long labels and retains a named 44px dismissal target. Neither announces changes automatically.

Toast uses label/bodyCompact roles and a 44px dismiss target; title, message, children and actions are optional. Supply announcement text for meaningful children-only updates. Real notifications announce politely by default; urgent opts into alert semantics, while announce=false is appropriate for static examples. Consumers own dismissal and focus continuation. ToastRegion retains history, scroll position and explicit latest-follow behavior; it does not own application notification state.

## Develop, validate and integrate

Read [AGENTS.md](AGENTS.md), [design intent](docs/design-system.md) and [component contracts](docs/design-system-components.md). Later selected source sections supersede earlier historical choices. The README describes current consumption, not the full decision history.

All changes—including docs—use a dedicated branch/worktree, update adopted source before behavior changes, pass validation there, then merge to main. Preserve unrelated work and provenance. An isolated checkout is preferable when main serves the catalog:

```sh
git worktree add ../design-system-change -b change/my-update main
cd ../design-system-change
npm ci
npm run dev
# In another terminal, if needed:
npm run storybook
```

Catalog development defaults to localhost:5173; Storybook to localhost:6006. Use the locked dependencies and a compatible Node runtime (the existing toolchain was built with Node 26.7/npm 11.19).

For package changes:

```sh
npm run check
npm run build
npm run build-storybook
npm pack
node scripts/verify-consumer.mjs ./release/decompozr-design-system-0.0.0.tgz
git diff --check
```

The consumer runner installs a hash-named copy into a fresh temporary plain-Svelte project, runs check/build and prints its path/hash. Run `npm run preview` there for browser checks on localhost:56464. It imports public package exports/fonts only. The explicit `?legacy-overlays` fixture mode disables native popover methods for fallback verification; it never changes the package or normal consumer mode.

Inspect meaningful keyboard/focus/disabled/form behavior and desktop, narrow, enlarged-root and coarse-pointer presentation. Record exact package identity, results and limits. Review the diff, commit on the change branch, reconcile any new main changes there and revalidate affected content before merging. Push and managed-service refresh are separate operations. [Readiness assessment](docs/professional-readiness.md) and [validation summary](docs/validation/README.md) preserve accepted outcomes and immutable historical evidence. Keep new raw execution logs, machine traces and generated screenshots outside Git; retain concise results, artifact identity and limits in authoritative docs.

## Managed catalog lifecycle

Never overwrite a serving managed build. The lifecycle guard enforces this. Build in an isolated checkout or stop the owned instance first:

```sh
npm run daemon -- status
npm run daemon -- stop
npm run build
npm run daemon -- start
npm run daemon -- status
```

`build/` is the catalog, `storybook-static/` the Storybook output and `dist/` the library. They and tarballs are ignored. The daemon uses current-session macOS launchd and loopback port 56460; logs/restart are available through `npm run daemon -- logs` and `-- restart`. Start/restart do not build. Status reports the actual checkout, PID, health and proxy independently.

Private Tailscale HTTPS configuration and ownership rules are in [app lifecycle](docs/app-lifecycle.md). Stop retains the owned proxy mapping; never replace unrelated routes. Storybook is a separate local development tool. Packaging alone neither refreshes the catalog nor installs a consumer.

## Compact selection, status and navigation

Use the additive [compact chrome APIs and Surface recipe](docs/compact-chrome.md) for a neutral floating Toolbar, thin selected outline, compact phone visuals with 44px native targets, semantic StatusIndicator and a guide-free hierarchy. Refresh is a packaged semantic icon. Consumers do not need internal CSS selectors or duplicate roving keyboard logic.

## Width-preserving navigation

Use `AppShell navigationMode="push"` when navigation should slide in and displace the page without compressing its width or changing line breaks. Desktop and phone behavior, focus/scroll handling and the Surface migration recipe are documented in [push navigation](docs/push-navigation.md). Overlay and responsive modes retain their existing contracts.

## Design studies

[Mobile composition concepts (2026-09-29)](docs/design-studies/mobile-compositions-20260929/README.md) preserves three visual alternatives and their original references. These are historical concept references; the current catalog implements floating, bottom-sheet and split compositions with shared content and adopted Milk Green styling.

## White transparent identity

Use `Logo palette="white"` for the optional white utility icon and wordmark, or `variant="compact"` for the icon. Its SVG has no surface rectangle. Provide a readable dark host surface; the logo does not add one. The existing default and cream/charcoal/sage/slate reference palettes remain supported. Standalone transparent vectors are exported as `@decompozr/design-system/logo-white.svg` and `@decompozr/design-system/icon-white.svg`. They retain the component's code-native geometry and Arial/Helvetica wordmark metrics, an engineering reconstruction of the archived reference rather than an outlined original font. No tagline is included.

The current colored identity uses `Logo palette="milk-green"`: four independent `brandColors` roles resolve the adopted light/dark recipe while the background stays transparent. The public `brandLightColors` and `brandDarkColors` maps project into matching full/icon SVG exports (`logo-milk-green-light.svg`, `logo-milk-green-dark.svg`, `icon-milk-green-light.svg`, `icon-milk-green-dark.svg`). White remains an optional utility. The original cream default and historical foreground recipes remain compatible, now without backplates. The catalog’s `/branding` guide shows actual artwork, role swatches, typography, placement recommendations and downloads.
